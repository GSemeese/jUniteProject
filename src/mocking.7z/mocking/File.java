package mocking;

public class File implements PrintJob{

    private String location;
    private String text;

    public File(String location, String text) {
        this.location = location;
        this.text = text;
    }
    
    @Override
    public boolean print(Printer printer) {
        printer.addPrintJob(this);
        return printer.startPrinting();
    }
    
}
