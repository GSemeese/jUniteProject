package mocking;

public interface PrintJob {
    public boolean print(Printer printer);
}
