
package mocking;

import java.util.ArrayList;
import java.util.List;

public class Printer {
    
    private List<PrintJob> printJobs;

    public Printer() {
        //complicated object
        printJobs = new ArrayList<>();
    }
    
    public void addPrintJob(PrintJob job){
        printJobs.add(job);
    }
    
    public boolean startPrinting(){
        //complicated method die een hele hoop bewerkingen moet doen
        //om uiteindelijk op true te komen
        return true;
    }
    
    
    
}
